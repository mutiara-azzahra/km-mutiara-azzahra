module.exports = {
  project: {
    android: {},
    ios: {},
  },

  assets: ['./src/assets/font'],
};
